const String appName = "e-Voting";
const String appNameCapital = "E-VOTING";
