package com.sb.evoting

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
